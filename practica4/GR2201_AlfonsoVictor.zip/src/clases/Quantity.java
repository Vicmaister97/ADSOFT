package clases;

/**
 * Enumeracion de los tipos de cantidades que se miden
 * @author Alfonso Carvajal, Victor Garcia
 *
 */
public enum Quantity {
	L, t;
	
}
